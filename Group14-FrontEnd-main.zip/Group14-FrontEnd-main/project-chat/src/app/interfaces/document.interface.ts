export interface Document {
  id: string;
  doc: string;
}
