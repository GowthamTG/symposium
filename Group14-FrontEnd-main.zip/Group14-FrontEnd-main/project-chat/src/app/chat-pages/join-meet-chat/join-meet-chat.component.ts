import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-join-meet-chat',
  templateUrl: './join-meet-chat.component.html',
  styleUrls: ['./join-meet-chat.component.scss']
})
export class JoinMeetChatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
