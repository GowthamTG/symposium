const MongoDBURL = {
  URL: "mongodb://localhost:27017/test",
};

module.exports = { MongoDBURL };
